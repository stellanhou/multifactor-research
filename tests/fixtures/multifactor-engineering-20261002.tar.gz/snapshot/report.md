# 多因子传统基线结果

- 运行：`multifactor-engineering-20261002`；状态：`engineering_complete`；用途：`engineering` / `internal_validation`
- 时段：`[2025-09-01T00:00:00+00:00, 2025-09-15T00:00:00+00:00)`；目标期限：24h；预热：168h
- 因子数：3；`model_called=false`；未改变上游卡片状态；未启动前向验证或发布。
- 数据处理合同：主库经过2026-09-22事后插值及边界补值。该窗口资金费结算标记价格含事后补写；没有可证实的完整逐行修复掩码。所有输入按retrospective_or_unknown处理，不证明完整因果历史策略收益。
- 数据来源的实际处理与因果性标记见 [data-provenance.json](inputs/data-provenance.json)。
- Spearman逐时截面相关和汇总见 [correlations.csv](factor_panels/correlations.csv) 与 [correlation_summary.csv](factor_panels/correlation_summary.csv)；报告包含绝对相关与分位数，供检查阶段变化和正负抵消。
- 因子比较、单因子和逐一移除结果均使用所有因子的共同有效样本；覆盖率主口径只计入账户信号窗，预热与全输入面板另列，见 [coverage_impact.csv](coverage_impact.csv)。
- 每次逐一移除后，剩余因子在相同共同样本上重新等权；权重没有拟合，仓位、调仓、成交成本与账户规则保持合同不变。等权及各消融的基础指标差值保存在 result.json。

## 因子代码

| 代码 | 创意卡 ID | 标题 | 源文件 |
|---|---|---|---|
| F1 | `fmv6-history-multi-20261002-0021--candidate-0001` | range_level_baseline · 赔率型、均衡型 | `/Users/stellan/量化投资/examples/strategy_research/multifactor/cards/fmv6-history-multi-20261002-0021--candidate-0001.json` |
| F2 | `fmv6-history-multi-20261002-0071--candidate-0003` | spot_perp_return_spread_realized_vol_state · 赔率型、稳定型、均衡型 | `/Users/stellan/量化投资/examples/strategy_research/multifactor/cards/fmv6-history-multi-20261002-0071--candidate-0003.json` |
| F3 | `fmv6-history-multi-20261002-0109--candidate-0002` | perp_to_spot_trade_count_ratio_level · 赔率型、均衡型 | `/Users/stellan/量化投资/examples/strategy_research/multifactor/cards/fmv6-history-multi-20261002-0109--candidate-0002.json` |

## 组合结果

| 实验 | 纳入因子 | 净收益 | 对等权净收益差 | 最大回撤 | 对等权回撤差 | 换手 | 手续费 | 滑点 | 资金费 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| single:F1 | F1 | -3.33% | +0.68% | 5.20% | -0.98% | 12.54 | 123.7 | 61.84 | 2.734 |
| single:F2 | F2 | -4.81% | -0.80% | 7.27% | +1.09% | 12.63 | 123.8 | 61.9 | 2.765 |
| single:F3 | F3 | -3.03% | +0.98% | 5.85% | -0.34% | 8.197 | 81.41 | 40.7 | 4.898 |
| equal_weight | F1, F2, F3 | -4.01% | +0.00% | 6.18% | +0.00% | 7.863 | 77.29 | 38.64 | 4.629 |
| drop:F1 | F2, F3 | -4.44% | -0.42% | 6.89% | +0.70% | 7.437 | 72.73 | 36.37 | 3.245 |
| drop:F2 | F1, F3 | -5.35% | -1.33% | 7.94% | +1.76% | 8.628 | 84.26 | 42.13 | 5.241 |
| drop:F3 | F1, F2 | -5.96% | -1.95% | 7.78% | +1.60% | 11.06 | 108.5 | 54.23 | 3.727 |
最大回撤按正幅度记录；相对差值为负表示回撤小于等权组合。资金费为账户现金流，正值表示收入。

等权组合成本压力（费率与滑点各乘 2）：净收益 -5.15%，最大回撤 7.07%。

## 解释边界

报告描述的是指定历史区间内的工程回放。收益为负或组合没有增量不影响流程是否完成；该结果本身不证明独立样本外表现，也不构成前向验证。
所有实验每段从独立初始资金开始；信号范围为 `[start-1h, end-1h)`，最后一小时只用于账户收盘估值，不再生成会在合同结束后成交的信号。订单、成交、逐事件资金费、持仓和逐时账本保存在各实验目录。信号时间按 UTC bar-open 标记，成交规则由确定性账户模块执行。

## 产物

- [冻结合同](contract.json)
- [卡片快照清单](cards.json)
- [输入快照](inputs/)
- [因子面板与相关性](factor_panels/)
- [运行结果与代码版本](result.json)
